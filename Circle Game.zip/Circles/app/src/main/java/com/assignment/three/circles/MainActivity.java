package com.assignment.three.circles;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Pradeep Mallikarjun.
 * RED ID 822032361
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(getString(R.string.circles_title));
    }
}
